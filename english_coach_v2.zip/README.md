# English Coach v2

A fun personal English vocabulary trainer.

## New in v2
- Spaced-repetition style review scheduling
- Again / Hard / Easy grading
- Automatic due-card queue (10-card daily session)
- Mastery progress based on review intervals
- Daily streak
- Pronunciation using browser speech synthesis
- Quick multiple-choice quiz
- Redesigned responsive interface
- Existing localStorage vocabulary is preserved and upgraded automatically

## Use
Open `index.html` or deploy it to your hosting service.

## Important
Vocabulary is stored in the browser's localStorage. Clearing browser site data can erase it.
